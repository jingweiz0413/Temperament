package com.example.temperament;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class summary extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summary);

        int[] total = getIntent().getIntArrayExtra("RESULT");
        int index = 0;
        for(int i = 1; i < 4; i++){
            if(total[i]>total[index])
                index = i;
        }
        TextView tv;

        switch(index){
            case 0:
                tv = (TextView) findViewById(R.id.conclusion);
                tv.setText("Choleric");
                tv = (TextView) findViewById(R.id.des);
                tv.setText(R.string.dofc);
                break;
            case 1:
                tv = (TextView) findViewById(R.id.conclusion);
                tv.setText("Sanguine");
                tv = (TextView) findViewById(R.id.des);
                tv.setText(R.string.dofs);
                break;
            case 2:
                tv = (TextView) findViewById(R.id.conclusion);
                tv.setText("Melancholic");
                tv = (TextView) findViewById(R.id.des);
                tv.setText(R.string.dofm);
                break;
            case 3:
                tv = (TextView) findViewById(R.id.conclusion);
                tv.setText("Phlegmatic");
                tv = (TextView) findViewById(R.id.des);
                tv.setText(R.string.dofp);
                break;
        }
        tv = (TextView) findViewById(R.id.sum);
        tv.setText("Choleric: "+total[0]+"\nSanguine: "+total[1]+"\nMelancholic: "+total[2]+"\nPhlegmatic: "+total[3]);
    }
}

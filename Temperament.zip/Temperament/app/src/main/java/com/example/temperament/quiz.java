package com.example.temperament;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.widget.RadioButton;
import android.widget.TextView;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import android.view.View;


public class quiz extends AppCompatActivity {
    ArrayList<String> strings;
    TextView tv;
    int num;
    ArrayList<Integer> selected;
    int score;
    int[] total;
    boolean clicked;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);
        initial();
        choose();
    }

    private void choose(){
        Random r = new Random();
        int n;
        while(true){
            n = r.nextInt(12) + (12*(num%4));
            if(selected.contains(n)){
                continue;
            }
            tv.setText(strings.get(n));
            return;
        }
    }

    private void initial(){
        total = new int[4];
        clicked = false;
        num = 0;
        tv = (TextView) findViewById(R.id.question);
        selected = new ArrayList<>();
        strings = new ArrayList<>();
        Resources myResources = getResources();

        InputStream myFile = myResources.openRawResource(R.raw.choleric);
        Scanner scan = new Scanner(myFile);
        while(scan.hasNextLine())
            strings.add(scan.nextLine());

        myFile = myResources.openRawResource(R.raw.sanguine);
        scan = new Scanner(myFile);
        while(scan.hasNextLine())
            strings.add(scan.nextLine());

        myFile = myResources.openRawResource(R.raw.melancholic);
        scan = new Scanner(myFile);
        while(scan.hasNextLine())
            strings.add(scan.nextLine());

        myFile = myResources.openRawResource(R.raw.phlegmatic);
        scan = new Scanner(myFile);
        while(scan.hasNextLine())
            strings.add(scan.nextLine());


    }

    public void radioB(View view){
        clicked = true;
        boolean checked = ((RadioButton) view).isChecked();
        if(view.getId() == R.id.sa && checked){
            score = 4;
        }
        if(view.getId() == R.id.pa && checked){
            score = 3;
        }
        if(view.getId() == R.id.ne && checked){
            score = 2;
        }
        if(view.getId() == R.id.pd && checked){
            score = 1;
        }
        if(view.getId() == R.id.sd && checked){
            score = 0;
        }
    }

    public void next(View view){
        if(clicked == false)
            return;
        if (num == 11) {
            total[num%4] += score;
            Intent intent = new Intent(this, summary.class);
            intent.putExtra("RESULT",total);
            startActivity(intent);
        }
        total[num%4] += score;
        num++;
        choose();
    }
}
